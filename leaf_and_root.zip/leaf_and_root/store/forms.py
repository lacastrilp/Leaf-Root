"""
Forms for customer registration in the store app.
Defines a form for creating new Customer instances with password confirmation.
"""

from django import forms
from .models import Customer  # Import the Customer model

class CustomerRegistrationForm(forms.ModelForm):
    password_confirmation = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Customer
        fields = ['name', 'email', 'address', 'phone', 'password', 'password_confirmation']
        widgets = {
            'password': forms.PasswordInput(),
            'password_confirmation': forms.PasswordInput(),
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirmation = cleaned_data.get("password_confirmation")

        if password and password_confirmation and password != password_confirmation:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned_data