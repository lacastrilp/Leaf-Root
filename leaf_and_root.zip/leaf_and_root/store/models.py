# Autor: [Tu Nombre]

from django.db import models
from django.contrib.auth.models import User

class Customer(models.Model):
    id_customer = models.AutoField(primary_key=True)
    name = models.CharField(max_length=200)
    email = models.EmailField(unique=True)
    address = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    password = models.CharField(max_length=200)
    
    # Relaciones
    # La Wishlist y el Cart del diagrama se crean automáticamente
    # cuando se crea el Customer. Los manejaremos en la lógica de negocio.

    class Meta:
        verbose_name = "Cliente"
        verbose_name_plural = "Clientes"

    def __str__(self):
        return self.name

class Product(models.Model):
    id_product = models.AutoField(primary_key=True)
    name = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=100)
    ingredients = models.TextField()
    stock = models.IntegerField(default=0)

    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"

    def __str__(self):
        return self.name

class Wishlist(models.Model):
    id_wishlist = models.AutoField(primary_key=True)
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Lista de Deseos"
        verbose_name_plural = "Listas de Deseos"

    def __str__(self):
        return f"Wishlist de {self.customer.name}"

class Review(models.Model):
    id_review = models.AutoField(primary_key=True)
    comment = models.TextField()
    rating = models.IntegerField()
    approved = models.BooleanField(default=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Reseña"
        verbose_name_plural = "Reseñas"

    def __str__(self):
        return f"Reseña de {self.customer.name} para {self.product.name}"

class Cart(models.Model):
    id_cart = models.AutoField(primary_key=True)
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Carrito de Compras"
        verbose_name_plural = "Carritos de Compras"

    def __str__(self):
        return f"Carrito de {self.customer.name}"

class ItemCart(models.Model):
    id_product = models.ForeignKey(Product, on_delete=models.CASCADE)
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    class Meta:
        verbose_name = "Item del Carrito"
        verbose_name_plural = "Items del Carrito"

    def __str__(self):
        return f"Item {self.id_product.name} en el carrito de {self.cart.customer.name}"

class PaymentMethod(models.Model):
    id_payment_method = models.AutoField(primary_key=True)
    type = models.CharField(max_length=50)
    card_number = models.CharField(max_length=16)
    expiration_date = models.CharField(max_length=5)
    security_code = models.CharField(max_length=3)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Método de Pago"
        verbose_name_plural = "Métodos de Pago"

    def __str__(self):
        return f"Tarjeta de {self.customer.name} - ****{self.card_number[-4:]}"

class Order(models.Model):
    id_order = models.AutoField(primary_key=True)
    order_date = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=50)
    cart = models.OneToOneField(Cart, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Orden"
        verbose_name_plural = "Órdenes"

    def __str__(self):
        return f"Orden #{self.id_order} - {self.customer.name}"
    
    def cancel(self):
        # La lógica está en services.py para mantener el modelo delgado
        from .services import cancel_order
        return cancel_order(self.id_order)

    # Método process_payment()
    def process_payment(self):
        # La lógica está en services.py
        from .services import process_order_payment
        return process_order_payment(self.id_order)
    
class ItemCart(models.Model):
    id_product = models.ForeignKey(Product, on_delete=models.CASCADE)
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    class Meta:
        verbose_name = "Item del Carrito"
        verbose_name_plural = "Items del Carrito"

    def __str__(self):
        return f"Item {self.id_product.name} en el carrito de {self.cart.customer.name}"
    
    # Método get_subtotal()
    def get_subtotal(self):
        """Calcula el subtotal para este item."""
        return self.quantity * self.id_product.price

