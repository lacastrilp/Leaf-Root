# Autor: [Tu Nombre]

from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import Product
from .services import get_top_selling_products, create_sales_invoice
from .services import (
    add_product_to_cart, remove_product_from_cart, clear_cart,
    create_new_customer, add_review, moderate_review,
    add_product_to_wishlist, remove_product_from_wishlist
)


from .forms import CustomerRegistrationForm

from django.contrib.auth import login, logout, authenticate




class ProductListView(ListView):
    model = Product
    template_name = 'store/home.html'
    context_object_name = 'products'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['top_products'] = get_top_selling_products(3)
        return context

class CustomerLoginView(LoginRequiredMixin, ListView):
    # La vista para el panel de usuario final
    template_name = 'store/customer_dashboard.html'
    # ... (lógica de la vista) ...

class AdminDashboardView(LoginRequiredMixin, ListView):
    # La vista para el panel de administrador
    template_name = 'store/admin_dashboard.html'
    # ... (lógica de la vista) ...
    
    
class HomeView(ListView):
    """Muestra la página de inicio con el listado de productos y el top 3 de más vendidos."""
    model = Product
    template_name = 'store/home.html'
    context_object_name = 'products'
    paginate_by = 10

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['top_selling_products'] = get_top_selling_products(3)
        return context


class ProductDetailView(View):
    """Muestra los detalles de un producto específico."""
    def get(self, request, product_id):
        product = get_object_or_404(Product, id_product=product_id)
        return render(request, 'store/product_detail.html', {'product': product})

class ProductSearchView(ListView):
    """Permite la búsqueda de productos por nombre."""
    model = Product
    template_name = 'store/search_results.html'
    context_object_name = 'products'

    def get_queryset(self):
        query = self.request.GET.get('q', '')
        queryset = Product.objects.filter(name__icontains=query)
        # Funcionalidad extra: Filtrado por tipo de producto (vegano/vegetariano)
        is_vegan = self.request.GET.get('vegan') == 'on'
        is_vegetarian = self.request.GET.get('vegetarian') == 'on'

        if is_vegan:
            queryset = queryset.filter(is_vegan=True)
        elif is_vegetarian:
            queryset = queryset.filter(is_vegetarian=True)

        return queryset


class LoginView(View):
    """Maneja el inicio de sesión del cliente o administrador."""
    def get(self, request):
        return render(request, 'store/login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff: # Asumiendo que los administradores son staff
                return redirect('admin_dashboard')
            else:
                return redirect('customer_dashboard')
        else:
            return render(request, 'store/login.html', {'error': 'Credenciales inválidas.'})


class AdminDashboardView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    """Panel de administración para la gestión de productos."""
    model = Product
    template_name = 'store/admin/admin_dashboard.html'
    context_object_name = 'products'

    def test_func(self):
        return self.request.user.is_staff


class GenerateInvoicePDF(LoginRequiredMixin, View):
    def get(self, request, order_id):
        try:
            # La lógica de creación del PDF se delega a un servicio
            pdf_file = create_sales_invoice(order_id)
            response = HttpResponse(pdf_file, content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="factura_{order_id}.pdf"'
            return response
        except Exception as e:
            return HttpResponse(f"Error generando la factura: {e}", status=500)
    


class AddToCartView(View):
    def post(self, request, product_id):
        # Suponiendo que el cliente tiene un carrito asociado a su sesión
        cart = request.user.customer.cart # Esto requiere un modelo de User personalizado o un OneToOneField
        add_product_to_cart(cart.id_cart, product_id, quantity=1)
        return redirect('home')

class RemoveFromCartView(View):
    def post(self, request, product_id):
        cart = request.user.customer.cart
        remove_product_from_cart(cart.id_cart, product_id)
        return redirect('cart_detail')

# Nueva vista para el registro
class RegisterView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'store/register.html', {'form': form})

    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            create_new_customer(form.cleaned_data)
            return redirect('login')
        return render(request, 'store/register.html', {'form': form})

# Nueva vista de Logout
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('home')

# Nueva vista para reseñas
class SubmitReviewView(View):
    def post(self, request, product_id):
        customer = request.user.customer # Requiere modelo de User personalizado
        comment = request.POST.get('comment')
        rating = request.POST.get('rating')
        add_review(product_id, customer.id_customer, comment, rating)
        return redirect('product_detail', product_id=product_id)

# Nueva vista para moderar reseñas
class ModerateReviewView(UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.is_staff
    
    def post(self, request, review_id):
        approved = request.POST.get('approved') == 'true'
        moderate_review(review_id, approved)
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))